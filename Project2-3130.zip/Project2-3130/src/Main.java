import java.math.BigInteger;

public class Main {
    public static void main(String[] args) {
        Calculation calculator = new Calculation();

        // Define the problem size
        long n0 = 48;

        // Calculate Fibonacci using the first method
        System.out.println("First Method:");
        long startTime = System.currentTimeMillis();
        long result1 = calculator.fibonacci_calculation(n0);
        long endTime = System.currentTimeMillis();
        System.out.println("Fibonacci(" + n0 + ") = " + result1);
        System.out.println("Execution Time: " + (endTime - startTime) + " milliseconds");

        // Calculate Fibonacci using the second method
        BigInteger input = BigInteger.valueOf(10000); // set to 0 for F0 and 10000 for F10000
        System.out.println("\nSecond Method:");
        long startTime2 = System.currentTimeMillis();
        BigInteger result2 = calculator.methodTwoCalculation(input);
        long endTime2 = System.currentTimeMillis();
        System.out.println("Fibonacci(" + input + ") = " + result2);
        System.out.println("Execution Time: " + (endTime2 - startTime2) + " milliseconds");
    }

    private static long findN0() {
        long n = 0;
        long startTime, endTime, execTime;

        do {
            startTime = System.currentTimeMillis(); // Convert Millseconds to seconds (20000 Milliseconds = 20 seconds)
            Calculation calculator = new Calculation();
            calculator.fibonacci_calculation(n);
            endTime = System.currentTimeMillis();
            execTime = endTime - startTime;
            n++;
        } while (execTime < 20000); // Until execution time exceeds 20 seconds

        // Now we have a value of n where execTime > 20000, let's find the closest value to 25 seconds
        long closestN0 = n - 1;
        long closestExecTime = execTime;

        while (execTime <= 30000) {
            closestN0 = n;
            closestExecTime = execTime;
            startTime = System.currentTimeMillis();
            Calculation calculator = new Calculation();
            calculator.fibonacci_calculation(n);
            endTime = System.currentTimeMillis();
            execTime = endTime - startTime;
            n++;
        }

        // Return the value of n0 closest to 25 seconds
        return closestN0;
    }
}

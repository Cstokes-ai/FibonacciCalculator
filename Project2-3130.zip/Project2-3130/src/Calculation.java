import java.math.BigInteger;

public class Calculation {
    private BigInteger[] knownF; // Array to store computed Fibonacci numbers

    public long fibonacci_calculation(long n) {
        if (n <= 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        }
        return fibonacci_calculation(n - 1) + fibonacci_calculation(n - 2);
    }

    // This method is for the calculation of time it takes the program to calculate
    public long recursiveTime(long n) {
        long start = System.currentTimeMillis(); // Capture start time
        long result = fibonacci_calculation(n);
        long end = System.currentTimeMillis(); // Capture end time
        long exec_time = end - start; // Calculate execution time
        System.out.println("Fibonacci(" + n + ") = " + result);
        System.out.println("Execution Time: " + exec_time + " milliseconds");
        return exec_time;
    }

    public BigInteger methodTwoCalculation(BigInteger i) {
        if (i.equals(BigInteger.ZERO)) {
            return BigInteger.ZERO; // Special case for Fibonacci(0)
        }

        knownF = new BigInteger[i.intValue() + 1]; // Initialize the array with size i + 1
        knownF[0] = BigInteger.ZERO; // Initialize the first two Fibonacci numbers
        knownF[1] = BigInteger.ONE;
        return fibonacci(i);
    }

    private BigInteger fibonacci(BigInteger i) {
        if (knownF[i.intValue()] != null) {
            return knownF[i.intValue()]; // Return the stored value if already computed
        }
        if (i.equals(BigInteger.ZERO)) {
            knownF[0] = BigInteger.ZERO;
            return BigInteger.ZERO;
        }
        if (i.equals(BigInteger.ONE)) {
            knownF[1] = BigInteger.ONE;
            return BigInteger.ONE;
        }

        // Compute Fibonacci numbers iteratively up to i
        for (int n = 2; n <= i.intValue(); n++) {
            knownF[n] = knownF[n - 1].add(knownF[n - 2]);
        }

        return knownF[i.intValue()];
    }
}
